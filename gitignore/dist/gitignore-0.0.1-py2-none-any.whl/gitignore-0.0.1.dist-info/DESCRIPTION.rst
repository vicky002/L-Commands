L - Commands
===========

Generate .gitignore files for you.

USAGE :
    type `gitignore ls` to find more details.
    example `gitignore jetbrain` this will generate gitignore file based on jetbrains IDE.


